from django.contrib import admin
from . models import Student, Recenzie, Coleg, Repartizare, Preferinta, Camin, MultimeStabila, Anunt

admin.site.register(Student)
admin.site.register(Recenzie)
admin.site.register(Coleg)
admin.site.register(Repartizare)
admin.site.register(Preferinta)
admin.site.register(Camin)
admin.site.register(MultimeStabila)
admin.site.register(Anunt)
