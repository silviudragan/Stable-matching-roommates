from django.apps import AppConfig


class StableConfig(AppConfig):
    name = 'stable'
