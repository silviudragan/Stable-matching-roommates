import operator
import random
import string

import MySQLdb
import datetime

from django.contrib.auth.models import User
from django.core.files.storage import FileSystemStorage
from django.core.paginator import Paginator
from django.db.backends import mysql
from django.http import HttpResponse
from django.http import JsonResponse
from django.shortcuts import render, redirect

from .forms import UserForm, LoginForm
from django.views.generic import View
from django.contrib.auth import authenticate, login, logout
from . models import Student, Recenzie, Coleg, Repartizare, Preferinta, Camin, MultimeStabila, Anunt

username = ""
email = ""
conn = MySQLdb.connect(host="localhost",
                       user="root",
                       passwd="Silviu01",
                       db="test")


def index(request, token):
    return render(request, 'stable/index.html', {'token': token})


class Login(View):
    form_class = LoginForm
    template_name = 'stable/login.html'

    def get(self, request):
        succes_email = request.GET.get('p', None)
        form = self.form_class(None)
        return render(request, self.template_name, {'form': form, 'succes_email': succes_email})

    def post(self, request):
        global username
        username = request.POST.get('nr_matricol', None)
        password = request.POST.get('parola', None)
        emailRecParola = request.POST.get('emailRecParola', None)
        if emailRecParola is None:
            user = authenticate(username=username, password=password)

            if user is not None:
                login(request, user)
                if username == "admin":
                    return redirect('administrator')

                size = 8
                chars = string.ascii_letters + string.digits
                token = ''.join(random.choice(chars) for _ in range(size))
                student = Student.objects.get(numar_matricol=username)
                student.token = token
                student.save()
                return render(request, 'stable/index.html', {'token': token})
            else:
                return render(request, 'stable/login.html')
        else:
            global email
            email = emailRecParola
            if "@info.uaic.ro" not in email:
                mesaj = "Emailul introdus nu este falid sau nu apartine domeniului facultatii."
                return render(request, 'stable/login.html', {'mesaj_email': mesaj})
            return redirect('resetPass')


class Logout(View):
    def get(self, request, token):
        try:
            student = Student.objects.get(token=token)
            student.token = ""
            student.save()
        except Exception:
            return redirect('login')
        logout(request)
        return redirect('login')


class Profil(View):

    def verificare_introducere_preferinte(self, nr_matricol):
        data = Preferinta.objects.filter(numar_matricol=nr_matricol)
        if len(data) == 0:
            return False
        else:
            return True

    template_name = 'stable/profil.html'

    def incarcare_preferinte(self, nr_matricol):
        nume_camin = ""
        colegi_camin = []
        warning = ""
        rep = Repartizare.objects.filter().all()
        data = Repartizare.objects.filter(numar_matricol=nr_matricol)
        if len(data) == 0:
            if len(rep) == 0:  # nimeni nu a fost repartizat la camin pana in momentul actual
                warning = "Repartizarea încă nu a fost realizată"
            else:
                warning = "Din nefericire nu aveți loc în cămin"
        else:
            st = Student.objects.get(numar_matricol=nr_matricol)
            d = conn.cursor()
            d.execute("SELECT s.nume from stable_student s "
                      "join stable_repartizare r on r.numar_matricol = s.numar_matricol "
                      "where r.camin=%s and s.numar_matricol!=%s and s.sex=%s", [data[0].camin, nr_matricol, st.sex])
            nume_camin = data[0].camin
            data = d.fetchall()
            for it in data:
                colegi_camin.append(it[0])
        return colegi_camin, nume_camin, warning

    def colegi_repartizati(self, nume_camin, nr_matricol):
        camere_repartizate = Camin.objects.filter(nume_camin=nume_camin)
        numar_camere = []
        for item in camere_repartizate:
            numar_camere.append(item.numar_camera)

        uid_colegii_repartizati = []
        numar_camera = 0
        for nr in numar_camere:
            camera = MultimeStabila.objects.filter(camera=Camin.objects.get(nume_camin=nume_camin, numar_camera=nr))
            studenti_camera = []
            if len(camera) > 0:
                for item in camera:
                    studenti_camera.append(item.coleg1)
                    studenti_camera.append(item.coleg2)
                    studenti_camera.append(item.coleg3)
                    studenti_camera.append(item.coleg4)
                    studenti_camera.append(item.coleg5)
                if nr_matricol in studenti_camera:
                    numar_camera = nr
                    for item in studenti_camera:
                        if len(item) > 0 and item != nr_matricol:
                            uid_colegii_repartizati.append(item)

        colegii_repartizati = []
        an_studiu = []
        grupa = []
        for uid in uid_colegii_repartizati:
            student = Student.objects.get(numar_matricol=uid)
            colegii_repartizati.append(student.nume)
        return colegii_repartizati, numar_camera

    def mesaje_admin(self):
        today = datetime.date.today()
        anunturi = Anunt.objects.all()
        anunturi_de_afisat = []
        for item in anunturi:
            if today <= item.deadline:
                if str(item.deadline) == "2500-12-31":
                    anunturi_de_afisat.append((item.titlu, item.mesaj, "-"))
                else:
                    anunturi_de_afisat.append((item.titlu, item.mesaj, str(item.deadline)))
        anunturi_de_afisat.sort(key=operator.itemgetter(2), reverse=True)
        return anunturi_de_afisat

    def get(self, request, token):
        try:
            student = Student.objects.get(token=token)
        except Exception:
            return redirect('login')
        nr_matricol = student.numar_matricol
        global username
        username = nr_matricol

        student = Student.objects.get(numar_matricol=nr_matricol)
        colegi_camin, nume_camin, warning = self.incarcare_preferinte(nr_matricol)
        introdus_preferinte = False

        colegii_repartizati, numar_camera = self.colegi_repartizati(nume_camin, nr_matricol)

        if self.verificare_introducere_preferinte(nr_matricol):
            introdus_preferinte = True

        anunturi = self.mesaje_admin()
        return render(request, self.template_name, {'student': student, 'colegi_camin': colegi_camin, 'nume_camin': nume_camin,
                                                    'introdus_preferinte': introdus_preferinte, 'colegii_repartizati': colegii_repartizati,
                                                    'numar_camera': numar_camera, 'anunturi': anunturi, 'token': token,  'warning': warning})

    def post(self, request, token):
        try:
            student = Student.objects.get(token=token)
        except Exception:
            return redirect('login')
        nr_matricol = student.numar_matricol
        c = conn.cursor()
        try:
            poza_profil = request.FILES['poza_profil']
            fs = FileSystemStorage()
            fs.save(poza_profil.name, poza_profil)
            c.execute("UPDATE stable_student set poza_profil=%s where numar_matricol=%s", [poza_profil, nr_matricol])
            conn.commit()
        except Exception:
            pass  # nu a fost incarcat nimic
        student = Student.objects.get(numar_matricol=nr_matricol)

        introdus_preferinte = False
        colegi_camin = ""
        if self.verificare_introducere_preferinte(nr_matricol):
            introdus_preferinte = True
        else:
            colegi_camin, nume_camin, warning = self.incarcare_preferinte(nr_matricol)
        aux = Repartizare.objects.filter(numar_matricol=nr_matricol)
        nume_camin = ""
        if len(aux) > 0:
            nume_camin = aux[0].camin

        anunturi = self.mesaje_admin()
        return render(request, self.template_name, {'student': student, 'colegi_camin': colegi_camin, 'nume_camin': nume_camin,
                                                    'introdus_preferinte': introdus_preferinte, 'anunturi': anunturi, 'token': token})


# o lista cu colegii de camera cu care a stat sau inca sta studentul cu respectivul numar matricol
def colegii_de_camera(nr_matricol):
    c = conn.cursor()
    c.execute("SELECT * from stable_coleg where coleg1=%s or coleg2=%s", [nr_matricol, nr_matricol])
    data = c.fetchall()
    nr_matricol_colegi = []
    for coleg in data:
        if coleg[1] == nr_matricol:
            nr_matricol_colegi.append(coleg[2])
        else:
            nr_matricol_colegi.append(coleg[1])
    colegi = []
    for coleg in nr_matricol_colegi:
        c.execute("SELECT nume FROM stable_student where numar_matricol=%s", [coleg])
        data = c.fetchone()
        nume = data[0]
        colegi.append(nume)
    c.close()
    return colegi


def obtine_recenzii():
    recenzii = []
    c = conn.cursor()
    c.execute("SELECT * FROM stable_recenzie order by data desc")
    for recenzie in c.fetchall():
        recenzii.append(list(recenzie))
    for i in range(0, len(recenzii)):
        # aflam numele expeditorului
        c.execute("SELECT nume FROM stable_student where numar_matricol=%s", [recenzii[i][1]])
        nume = c.fetchone()
        recenzii[i][1] = nume[0]

        # aflam numele destinatarului
        c.execute("SELECT nume FROM stable_student where numar_matricol=%s", [recenzii[i][2]])
        nume = c.fetchone()
        recenzii[i][2] = nume[0]
        recenzii[i][4] = str(recenzii[i][4])

    c.close()
    return recenzii


ITEMS_ON_PAGE = 5


class Recenzii(View):
    template_name = 'stable/recenzie.html'

    def url_poze(self, recenzii):
        poze = dict()
        for item in recenzii:
            aux = Student.objects.filter(nume=item[1])

            if aux[0].poza_profil == '1':
                if aux[0].sex == 'F':
                    poze[item[1]] = '14.png'
                else:
                    poze[item[1]] = '13.png'
            else:
                poze[item[1]] = aux[0].poza_profil

            aux = Student.objects.filter(nume=item[2])

            if aux[0].poza_profil == '1':
                if aux[0].sex == 'F':
                    poze[item[2]] = '14.png'
                else:
                    poze[item[2]] = '13.png'
            else:
                poze[item[2]] = aux[0].poza_profil
        return poze

    def camin_cazat(self, recenzii):
        camin = dict()
        for item in recenzii:
            st = Student.objects.filter(nume=item[1])
            st2 = Student.objects.filter(nume=item[2])

            aux = Coleg.objects.filter(coleg1=st[0].numar_matricol, coleg2=st2[0].numar_matricol)
            aux2 = Coleg.objects.filter(coleg1=st2[0].numar_matricol, coleg2=st[0].numar_matricol)
            if len(aux) > 0:
                camin[item[1]] = aux[0].nume_camin
                camin[item[2]] = aux[0].nume_camin
            elif len(aux2) > 0:
                camin[item[1]] = aux2[0].nume_camin
                camin[item[2]] = aux2[0].nume_camin
        return camin

    def get(self, request, token):
        page = request.GET.get('page', 1)
        try:
            student = Student.objects.get(token=token)
            nr_matricol = student.numar_matricol
        except Exception:
            return redirect('login')

        student = Student.objects.get(numar_matricol=nr_matricol)
        recenzii = obtine_recenzii()

        poze = self.url_poze(recenzii)
        camin = self.camin_cazat(recenzii)
        p = Paginator(recenzii, ITEMS_ON_PAGE)
        colegi = colegii_de_camera(nr_matricol)
        return render(request, self.template_name, {'student': student, 'recenzii': p.page(page), 'colegi': colegi,
                                                    'nr_matricol': nr_matricol, 'poze': poze, 'camin': camin, 'token': token})

    def post(self, request, token):
        try:
            student = Student.objects.get(token=token)
            nr_matricol_token = student.numar_matricol
        except Exception:
            return redirect('login')

        page = request.GET.get('page', 1)
        nume_coleg = request.POST.get('numeColeg', '')
        calificativ = request.POST.get('notaColeg', '')
        mesaj = request.POST.get('mesajColeg', '')
        data = nume_coleg

        if nume_coleg == '':
            student = Student.objects.get(numar_matricol=nr_matricol_token)
            recenzii = obtine_recenzii()
            colegi = colegii_de_camera(nr_matricol_token)
            p = Paginator(recenzii, ITEMS_ON_PAGE)
            warning = "Nu a fost selectat nici un nume pentru recenzie"
            poze = self.url_poze(recenzii)
            camin = self.camin_cazat(recenzii)
            return render(request, self.template_name, {'student': student, 'recenzii': p.page(page), 'colegi': colegi,
                                                        'warning': warning, "nr_matricol": nr_matricol_token, 'poze': poze, 'camin': camin, 'token': token})
        nume = data
        c = conn.cursor()

        c.execute("SELECT numar_matricol from stable_student where nume=%s", [nume])
        nr_matricol = c.fetchone()

        colegi = colegii_de_camera(nr_matricol_token)
        student = Student.objects.get(numar_matricol=nr_matricol_token)
        c.execute("SELECT * from stable_recenzie where from_uid=%s and to_uid=%s", [nr_matricol_token, nr_matricol])
        data = c.fetchone()

        if data:
            recenzii = obtine_recenzii()
            warning = "Exista deja o recenzie facuta pentru " + nume
            p = Paginator(recenzii, ITEMS_ON_PAGE)
            poze = self.url_poze(recenzii)
            camin = self.camin_cazat(recenzii)
            return render(request, self.template_name, {'student': student, 'recenzii': p.page(page), 'colegi': colegi,
                                                        'warning': warning, "nr_matricol": nr_matricol_token, 'poze': poze, 'camin': camin, 'token': token})

        c.execute("SELECT numar_matricol from stable_student where nume=%s", [nume])
        nr_matricol = c.fetchone()

        c.execute("INSERT into stable_recenzie(from_uid, to_uid, mesaj, calificativ, data) "
                  "VALUES(%s, %s, %s, %s, %s)", [nr_matricol_token, nr_matricol, mesaj, calificativ, datetime.date.today()])
        conn.commit()
        c.close()
        recenzii = obtine_recenzii()
        succes = "Recenzia pentru " + nume + " " + " a fost adaugata."
        p = Paginator(recenzii, ITEMS_ON_PAGE)
        poze = self.url_poze(recenzii)
        camin = self.camin_cazat(recenzii)
        return render(request, self.template_name, {'student': student, 'recenzii': p.page(page), 'colegi': colegi,
                                                    'succes': succes, "nr_matricol": nr_matricol_token, 'poze': poze, 'camin': camin, 'token': token})


def aflare_nr_matricol(nume):
    c = conn.cursor()
    c.execute("SELECT numar_matricol from stable_student where nume=%s", [nume])
    data = c.fetchone()
    c.close()
    return data


###############################################################################################################
######################################## Functii pentru apelurile AJAX ########################################
###############################################################################################################


def display_info_coleg(request):
    coleg = request.GET.get('numeColeg', None)
    c = conn.cursor()
    c.execute("SELECT * from stable_student where nume=%s", [coleg])
    rez = c.fetchone()
    nr_matricol = rez[2]
    c.close()
    data = {
        'Nume:': rez[0],
        'An:': rez[2],
        'Grupa:': rez[3],
        'Poza:': rez[5],
    }
    if data['Poza:'] == "1":
        if rez[4] == "M":
            data['Poza:'] = "13.png"
        else:
            data['Poza:'] = "14.png"
    return JsonResponse(data)


def recenzii_facute(request):
    nr_matricol = request.GET.get('nr_matricol', None)

    recenzii = []
    c = conn.cursor()

    c.execute("SELECT * FROM stable_recenzie where from_uid=%s order by data desc", [nr_matricol])
    for recenzie in c.fetchall():
        recenzii.append(list(recenzie))
    for i in range(0, len(recenzii)):
        # aflam numele expeditorului
        c.execute("SELECT nume FROM stable_student where numar_matricol=%s", [recenzii[i][1]])
        nume = c.fetchone()
        recenzii[i][1] = nume[0]

        # aflam numele destinatarului
        c.execute("SELECT nume FROM stable_student where numar_matricol=%s", [recenzii[i][2]])
        nume = c.fetchone()
        recenzii[i][2] = nume[0]
    c.close()

    data = {}
    it = 0
    for rec in recenzii:
        # nume camin
        st = Student.objects.filter(nume=rec[1])
        st2 = Student.objects.filter(nume=rec[2])

        aux = Coleg.objects.filter(coleg1=st[0].numar_matricol, coleg2=st2[0].numar_matricol)
        aux2 = Coleg.objects.filter(coleg1=st2[0].numar_matricol, coleg2=st[0].numar_matricol)
        eticheta = 'info' + str(it)
        it += 1
        if len(aux) > 0:
            data[eticheta] = aux[0].nume_camin
        elif len(aux2) > 0:
            data[eticheta] = aux2[0].nume_camin
        else:
            data[eticheta] = "-"

        aux = Student.objects.filter(nume=rec[1])
        eticheta = 'info' + str(it)
        it += 1
        if aux[0].poza_profil == '1':
            if aux[0].sex == 'F':
                data[eticheta] = '14.png'
            else:
                data[eticheta] = '13.png'
        else:
            data[eticheta] = str(aux[0].poza_profil)

        eticheta = 'info' + str(it)
        it += 1
        data[eticheta] = rec[1]

        aux = Student.objects.filter(nume=rec[2])
        eticheta = 'info' + str(it)
        it += 1
        if aux[0].poza_profil == '1':
            if aux[0].sex == 'F':
                data[eticheta] = '14.png'
            else:
                data[eticheta] = '13.png'
        else:
            data[eticheta] = str(aux[0].poza_profil)

        for i in range(2, len(rec)):
            eticheta = 'info' + str(it)
            it += 1
            data[eticheta] = rec[i]

    return JsonResponse(data)


def recenzii_primite(request):
    nr_matricol = request.GET.get('nr_matricol', None)

    recenzii = []
    c = conn.cursor()

    c.execute("SELECT * FROM stable_recenzie where to_uid=%s order by data desc", [nr_matricol])
    for recenzie in c.fetchall():
        recenzii.append(list(recenzie))
    for i in range(0, len(recenzii)):
        # aflam numele expeditorului
        c.execute("SELECT nume FROM stable_student where numar_matricol=%s", [recenzii[i][1]])
        nume = c.fetchone()
        recenzii[i][1] = nume[0]

        # aflam numele destinatarului
        c.execute("SELECT nume FROM stable_student where numar_matricol=%s", [recenzii[i][2]])
        nume = c.fetchone()
        recenzii[i][2] = nume[0]
    c.close()

    data = {}
    it = 0
    for rec in recenzii:
        # nume camin
        st = Student.objects.filter(nume=rec[1])
        st2 = Student.objects.filter(nume=rec[2])

        aux = Coleg.objects.filter(coleg1=st[0].numar_matricol, coleg2=st2[0].numar_matricol)
        aux2 = Coleg.objects.filter(coleg1=st2[0].numar_matricol, coleg2=st[0].numar_matricol)
        eticheta = 'info' + str(it)
        it += 1
        if len(aux) > 0:
            data[eticheta] = aux[0].nume_camin
        elif len(aux2) > 0:
            data[eticheta] = aux2[0].nume_camin
        else:
            data[eticheta] = ""

        # poza
        aux = Student.objects.filter(nume=rec[1])
        eticheta = 'info' + str(it)
        it += 1
        if aux[0].poza_profil == '1':
            if aux[0].sex == 'F':
                data[eticheta] = '14.png'
            else:
                data[eticheta] = '13.png'
        else:
            data[eticheta] = str(aux[0].poza_profil)

        eticheta = 'info' + str(it)
        it += 1
        data[eticheta] = rec[1]

        aux = Student.objects.filter(nume=rec[2])
        eticheta = 'info' + str(it)
        it += 1
        if aux[0].poza_profil == '1':
            if aux[0].sex == 'F':
                data[eticheta] = '14.png'
            else:
                data[eticheta] = '13.png'
        else:
            data[eticheta] = str(aux[0].poza_profil)

        for i in range(2, len(rec)):
            eticheta = 'info' + str(it)
            it += 1
            data[eticheta] = rec[i]
    return JsonResponse(data)


def toate_recenziile(request):
    recenzii = []
    c = conn.cursor()

    c.execute("SELECT * FROM stable_recenzie order by data desc")
    for recenzie in c.fetchall():
        recenzii.append(list(recenzie))
    for i in range(0, len(recenzii)):
        # aflam numele expeditorului
        c.execute("SELECT nume FROM stable_student where numar_matricol=%s", [recenzii[i][1]])
        nume = c.fetchone()
        recenzii[i][1] = nume[0]

        # aflam numele destinatarului
        c.execute("SELECT nume FROM stable_student where numar_matricol=%s", [recenzii[i][2]])
        nume = c.fetchone()
        recenzii[i][2] = nume[0]
    c.close()

    data = {}
    it = 0
    for rec in recenzii:
        for i in rec:
            eticheta = 'info' + str(it)
            it += 1
            data[eticheta] = i
    return JsonResponse(data)


def preferinte_student(request):
    nume_preferinte = request.GET.get('nume_preferinte', None)
    lista_preferinte = nume_preferinte.split('+')[:-1]
    c = conn.cursor()
    importanta = 1
    for item in lista_preferinte:
        nr_matricol = aflare_nr_matricol(item)
        c.execute('INSERT into stable_preferinta (numar_matricol, uid_preferinta, importanta) values (%s, %s, %s)',
                  [username, nr_matricol, importanta])
        importanta += 1
    conn.commit()
    c.close()
    return JsonResponse({})


###############################################################################################################
###############################################################################################################
###############################################################################################################


def trimite_email(destinatar, cod_verificare):
    # implementare care a functionat pentru o perioada de timp, iar dupa din motive necunoscute nu a mai functionat
    """
    import smtplib
    gmail_user = "stablematchingroommates@gmail.com"
    gmail_pwd = "StableRommates135680"
    SUBJECT = "Resetare parola"
    TEXT = "Foloseste codul urmator pentru resetarea parolei: " + cod_verificare + "."
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.ehlo()

    server = smtplib.SMTP_SSL('smtp.googlemail.com', 465)

    server.login(gmail_user, gmail_pwd)
    BODY = '\r\n'.join(['To: %s' % destinatar,
                        'From: %s' % gmail_user,
                        'Subject: %s' % SUBJECT,
                        '', TEXT])

    server.sendmail(gmail_user, destinatar, BODY)
    """

    import smtplib
    fromaddr = 'stablematchingroommates@gmail.com'
    toaddrs = destinatar
    msg = "Foloseste codul urmator pentru resetarea parolei: " + cod_verificare + "."
    username = 'stablematchingroommates@gmail.com'
    password = 'StableRommates135680'
    SUBJECT = "Resetare parola"

    server = smtplib.SMTP('smtp.gmail.com:587')
    server.ehlo()
    BODY = '\r\n'.join(['To: %s' % destinatar,
                        'From: %s' % fromaddr,
                        'Subject: %s' % SUBJECT,
                        '', msg])
    server.starttls()
    server.login(username, password)
    server.sendmail(fromaddr, toaddrs, BODY)
    server.quit()
    print('email sent')


def id_generator(size=7, chars=string.ascii_uppercase + string.digits):
    return ''.join(random.choice(chars) for _ in range(size))


class ResetPass(View):
    template_name = 'stable/resetPass.html'

    def get(self, request):
        cod_verificare = id_generator()
        c = conn.cursor()

        c.execute("UPDATE stable_student set cod_reset_parola=%s", [cod_verificare])
        conn.commit()
        c.close()

        trimite_email(email, cod_verificare)
        return render(request, self.template_name, {'email': email})

    def post(self, request):
        codVerificare = request.POST.get('codVerificare', '')
        password = request.POST.get('password', '')
        re_password = request.POST.get('re_password', '')

        c = conn.cursor()
        c.execute("SELECT cod_reset_parola, numar_matricol from stable_student where email=%s", [email])
        cod_valid, username = c.fetchone()

        if codVerificare == cod_valid:
            if password == re_password:
                user = User.objects.get(username=username)
                user.set_password(password)
                user.save()
                c.execute("UPDATE stable_student set cod_reset_parola=''")
                conn.commit()
                mesaj = "succes"
                return redirect('/login/?p=%s' % mesaj)
                # return redirect('login')
                # return render(request, 'stable/login.html', {'mesaj_reset': mesaj})

            mesaj = "Parolele nu se potrivesc"
            return render(request, 'stable/resetPass.html', {'mesaj_reset': mesaj})

        c.close()
        mesaj = "Codul de verificare nu este valid"
        return render(request, 'stable/resetPass.html', {'mesaj_reset': mesaj})
